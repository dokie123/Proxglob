# school-bypasses
School Bypasses that should work for blockers like Securly, iBoss, and GoGuardian. End internet censorship! (without using Holy Unblocker)

# How to use
download as zip or from releases and go into the html make sure u extract it ur welcome 8)

# Note with Watchkin
it may not work. You can use an alternative that my friend made over at https://levif1234.github.io/Watchkin.
